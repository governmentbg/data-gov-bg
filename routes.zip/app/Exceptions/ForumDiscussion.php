<?php

namespace App\Exceptions;

class ForumDiscussion extends \Exception {}
