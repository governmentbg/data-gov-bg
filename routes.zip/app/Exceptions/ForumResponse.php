<?php

namespace App\Exceptions;

class ForumResponse extends \Exception {}
