<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\QueryException;

class ToolController extends Controller
{
    const DRIVER_MYSQL = 1;
    const DRIVER_PGSQL = 2;
    const DRIVER_OCI = 3;
    const DRIVER_INFORMIX = 4;
    const DRIVER_SQLSRV = 5;

    private function getDrivers()
    {
        return [
            self::DRIVER_MYSQL      => 'mysql',
            self::DRIVER_PGSQL      => 'pgsql',
            self::DRIVER_OCI        => 'oci',
            self::DRIVER_INFORMIX   => 'informix',
            self::DRIVER_SQLSRV     => 'sqlsrv',
        ];
    }

    public function config(Request $request)
    {
        $post = $request->all();
        $foundData = false;
        $class = 'index';

        if ($request->has('test') || $request->has('save')) {
            $validator = \Validator::make($request->all(), [
                'source_db_user'        => 'required|string|max:191',
                'source_db_host'        => 'required|string|max:191',
                'source_db_name'        => 'required|string|max:191',
                'source_db_pass'        => 'nullable|string|max:191',
                'notification_email'    => 'nullable|email|max:191',
                'query'                 => 'required|string|max:8000',
            ]);

            if (!$validator->fails()) {
                $username = $post['source_db_user'];
                $host = $post['source_db_host'];
                $dbName = $post['source_db_name'];
                $password = $post['source_db_pass'];
                $query = $post['query'];

                $driver = $this->testConnection($host, $dbName, $username, $password);

                if ($driver) {
                    if ($request->has('save')) {
                        try {
                            $this->saveQuery($post);

                            session()->flash('alert-success', __('custom.conn_success'));
                        } catch (QueryException $e) {
                            session()->flash('alert-danger', __('custom.conn_error') .' ('. $e->getMessage() .')');
                        }
                    } else {
                        try {
                            $foundData = $this->fetchData($query, $driver, $host, $dbName, $username, $password);

                            session()->flash('alert-success', __('custom.conn_success'));
                        } catch (\PDOException $e) {
                            session()->flash('alert-danger', __('custom.conn_error') .' ('. $e->getMessage() .')');
                        }
                    }
                } else {
                    session()->flash('alert-danger', __('custom.conn_error'));
                }
            }

            if (!session()->has('alert-success')) {
                return back()->withInput()->withErrors($validator->errors()->messages());
            }
        }

        return view('tool/config', compact('class', 'post', 'foundData'));
    }

    private function saveQuery($data)
    {

    }

    private function testConnection($host, $dbName, $username, $password)
    {
        foreach ($this->getDrivers() as $id => $driver) {
            if ($this->checkConnection($driver, $host, $dbName, $username, $password)) {
                return $id;
            } else {
                continue;
            }
        }

        return false;
    }

    private function checkConnection($driver, $host, $dbName, $username, $password = null)
    {
        try {
            $connection = $this->getConnection($driver, $host, $dbName, $username, $password);

            return true;
        } catch(\PDOException $e) {}

        return false;
    }

    private function fetchData($query, $driver, $host, $dbName, $username, $password = null)
    {
        $driver = $this->getDrivers()[$driver];

        $connection = $this->getConnection($driver, $host, $dbName, $username, $password);

        $stmt = $connection->prepare($query);
        $stmt->execute();

        $result = $stmt->setFetchMode(\PDO::FETCH_ASSOC);
        $result = $stmt->fetchAll();

        if (!empty($result[0])) {
            $result = array_merge([array_keys($result[0])], $result);
        }

        return empty($result) ? [] : $result;
    }

    private function getConnection($driver, $host, $dbName, $username, $password)
    {
        $connection = new \PDO($driver .':host='. $host .';dbname='. $dbName, $username, $password);
        $connection->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);

        return $connection;
    }
}
