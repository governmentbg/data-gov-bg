<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSignalsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (!env('IS_TOOL')) {
            Schema::create('signals', function (Blueprint $table) {
                $table->increments('id');
                $table->integer('resource_id')->unsigned();
                $table->foreign('resource_id')->references('id')->on('resources');
                $table->text('descript');
                $table->string('firstname', 100);
                $table->string('lastname', 100);
                $table->string('email');
                $table->unsignedTinyInteger('status');
                $table->timestamps();
                $table->integer('updated_by')->unsigned()->nullable();
                $table->foreign('updated_by')->references('id')->on('users');
                $table->integer('created_by')->unsigned();
                $table->foreign('created_by')->references('id')->on('users');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('signals');
    }
}
