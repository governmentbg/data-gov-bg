<span
    class="js-translations"
    data-search="{{ __('custom.search_table') }}"
    data-info="{{ __('custom.info') }}"
    data-info-filtered="{{ __('custom.info_filtered') }}"
    data-info-empty="{{ __('custom.info_empty') }}"
    data-zero-records="{{ __('custom.zero_records') }}"
    data-length-menu="{{ __('custom.length_menu') }}"
    data-next="{{ __('custom.next') }}"
    data-previous="{{ __('custom.previous') }}"
    data-first="{{ __('custom.first') }}"
    data-last="{{ __('custom.last') }}"
>
