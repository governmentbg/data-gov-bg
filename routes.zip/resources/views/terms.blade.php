@extends('layouts.app')

@section('content')
<div class="container">
    <div class="col-xs-12 p-lg">
        <div>
            <h3>{{ __('custom.terms_and_conditions') }}</h3><br>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                incididunt ut labore et magna aliqua. Adipiscing commodo elit at imperdiet.
                Nec nam aliquam sem et tortor consequat. Placerat duis ultricies lacus sed turpis
                tincidunt id. Eu mi bibendum neque egestas congue quisque egestas diam. Hac habitasse
                platea dictumst quisque sagittis purus sit. Tristique senectus et netus et malesuada fames.
                Maecenas sed enim ut sem viverra aliquet eget sit. Scelerisque viverra mauris in aliquam sem fringilla.
                Nullam ac tortor vitae purus faucibus ornare suspendisse. Adipiscing elit duis tristique sollicitudin.
                Ornare arcu dui vivamus arcu felis bibendum ut. Sit amet risus nullam eget felis eget nunc. Lobortis elementum
                nibh tellus molestie nunc non blandit massa enim. Augue eget arcu dictum varius duis. Viverra accumsan in nisl
                nisi scelerisque. Etiam erat velit scelerisque in dictum non. Pulvinar mattis nunc sed blandit.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                incididunt ut labore et magna aliqua. Adipiscing commodo elit at imperdiet.
                Nec nam aliquam sem et tortor consequat. Placerat duis ultricies lacus sed turpis
                tincidunt id. Eu mi bibendum neque egestas congue quisque egestas diam. Hac habitasse
                platea dictumst quisque sagittis purus sit. Tristique senectus et netus et malesuada fames.
                Maecenas sed enim ut sem viverra aliquet eget sit. Scelerisque viverra mauris in aliquam sem fringilla.
                Nullam ac tortor vitae purus faucibus ornare suspendisse. Adipiscing elit duis tristique sollicitudin.
                Ornare arcu dui vivamus arcu felis bibendum ut. Sit amet risus nullam eget felis eget nunc. Lobortis elementum
                nibh tellus molestie nunc non blandit massa enim. Augue eget arcu dictum varius duis. Viverra accumsan in nisl
                nisi scelerisque. Etiam erat velit scelerisque in dictum non. Pulvinar mattis nunc sed blandit.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                incididunt ut labore et magna aliqua. Adipiscing commodo elit at imperdiet.
                Nec nam aliquam sem et tortor consequat. Placerat duis ultricies lacus sed turpis
                tincidunt id. Eu mi bibendum neque egestas congue quisque egestas diam. Hac habitasse
                platea dictumst quisque sagittis purus sit. Tristique senectus et netus et malesuada fames.
                Maecenas sed enim ut sem viverra aliquet eget sit. Scelerisque viverra mauris in aliquam sem fringilla.
                Nullam ac tortor vitae purus faucibus ornare suspendisse. Adipiscing elit duis tristique sollicitudin.
                Ornare arcu dui vivamus arcu felis bibendum ut. Sit amet risus nullam eget felis eget nunc. Lobortis elementum
                nibh tellus molestie nunc non blandit massa enim. Augue eget arcu dictum varius duis. Viverra accumsan in nisl
                nisi scelerisque. Etiam erat velit scelerisque in dictum non. Pulvinar mattis nunc sed blandit.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                incididunt ut labore et magna aliqua. Adipiscing commodo elit at imperdiet.
                Nec nam aliquam sem et tortor consequat. Placerat duis ultricies lacus sed turpis
                tincidunt id. Eu mi bibendum neque egestas congue quisque egestas diam. Hac habitasse
                platea dictumst quisque sagittis purus sit. Tristique senectus et netus et malesuada fames.
                Maecenas sed enim ut sem viverra aliquet eget sit. Scelerisque viverra mauris in aliquam sem fringilla.
                Nullam ac tortor vitae purus faucibus ornare suspendisse. Adipiscing elit duis tristique sollicitudin.
                Ornare arcu dui vivamus arcu felis bibendum ut. Sit amet risus nullam eget felis eget nunc. Lobortis elementum
                nibh tellus molestie nunc non blandit massa enim. Augue eget arcu dictum varius duis. Viverra accumsan in nisl
                nisi scelerisque. Etiam erat velit scelerisque in dictum non. Pulvinar mattis nunc sed blandit.
            </p>
        </div>
    </div>
</div>
@endsection
