@extends('layouts.app')

@section('content')
<form method="post" class="form-horisontal config-form">
    <div class="container p-l-r-none">
        @include('partials.alerts-bar')

        <div class="js-config-control-form config-control-form">
            {{ csrf_field() }}
            <div class="form-group required">
                <label class="col-sm-4 col-xs-12 col-form-label">{{ __('custom.title') }}:</label>
                <div class="col-sm-8">
                    <input
                        type="text"
                        class="input-border-r-12 form-control"
                        name="title"
                        value="{{ old('title') }}"
                    >
                    <span class="error">{{ $errors->first('title') }}</span>
                </div>
            </div>
            <div class="form-group required">
                <label class="col-sm-4 col-xs-12 col-form-label m-b-sm">{{ __('custom.connection_type') }}:</label>
                @foreach (['dbms', 'file'] as $i => $name)
                    <div class="col-sm-4 col-xs-6 m-b-md">
                        <label class="radio-label {{ $i ? 'pull-right' : null }}">
                            {{ uctrans('custom.'. $name) }}
                            <div class="js-check">
                                <input
                                    type="radio"
                                    name="type"
                                    value="{{ $name }}"
                                    @if (!empty(old('type')) && old('type') == $name)
                                        {{ 'checked' }}
                                    @elseif (empty(old('type')) && $name == 'dbms')
                                        {{ 'checked' }}
                                    @endif
                                >
                            </div>
                        </label>
                    </div>
                @endforeach
                @if (isset($errors) && $errors->has('type'))
                    <div class="row">
                        <div class="col-xs-12 m-l-md">
                            <span class="error">{{ $errors->first('type') }}</span>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>

    <hr class="section-line"></hr>

    <div class="container p-l-r-none m-b-lg">
        <div class="js-dbms-form dbms-form">
            <div class="form-group required">
                <label class="col-md-3">{{ __('custom.host') }}:</label>
                <div class="col-md-9">
                    <input
                        class="form-control"
                        name="source_db_host"
                        value="{{ old('source_db_host', empty($post['source_db_host']) ? '' : $post['source_db_host']) }}"
                        placeholder="127.0.0.1:3306"
                    >
                    <span class="error">{{ $errors->first('source_db_host') }}</span>
                </div>
            </div>
            <div class="form-group required">
                <label class="col-md-3">{{ __('custom.user_name') }}:</label>
                <div class="col-md-9">
                    <input
                        class="form-control"
                        name="source_db_user"
                        value="{{ old('source_db_user', empty($post['source_db_user']) ? '' : $post['source_db_user']) }}"
                    >
                    <span class="error">{{ $errors->first('source_db_user') }}</span>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-3">{{ __('custom.password') }}:</label>
                <div class="col-md-9">
                    <input
                        class="form-control"
                        name="source_db_pass"
                        value="{{ old('source_db_pass', empty($post['source_db_pass']) ? '' : $post['source_db_pass']) }}"
                    >
                    <span class="error">{{ $errors->first('source_db_pass') }}</span>
                </div>
            </div>
            <div class="form-group required">
                <label class="col-md-3">{{ __('custom.db_name') }}:</label>
                <div class="col-md-9">
                    <input
                        class="form-control"
                        name="source_db_name"
                        value="{{ old('source_db_name', empty($post['source_db_name']) ? '' : $post['source_db_name']) }}"
                    >
                    <span class="error">{{ $errors->first('source_db_name') }}</span>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-3">{{ __('custom.notification_email') }}:</label>
                <div class="col-md-9">
                    <input
                        class="form-control"
                        name="notification_email"
                        value="{{ old('notification_email', empty($post['notification_email']) ? '' : $post['notification_email']) }}"
                    >
                    <span class="error">{{ $errors->first('notification_email') }}</span>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-3"></label>
                <div class="col-md-9">
                    <input
                        class="btn btn-primary generate-btn form-control"
                        type="submit"
                        name="generate"
                        value="{{ __('custom.generate') }} {{ __('custom.command') }}"
                    >
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-3"></label>
                <div class="col-md-9">
                    <textarea
                        type="text"
                        class="input-border-r-12 form-control"
                        name="query"
                    >{{ old('query', empty($post['query']) ? 'SELECT * FROM ___' : $post['query']) }}</textarea>
                    <span class="error">{{ $errors->first('query') }}</span>
                </div>
            </div>
            <div class="form-group col-md-9 col-md-offset-3">
                <input
                    type="submit"
                    class="btn btn-primary test-btn"
                    name="test"
                    value="{{ __('custom.test_connection') }}"
                >
                <input
                    type="submit"
                    class="btn btn-primary save-btn pull-right"
                    name="save"
                    value="{{ uctrans('custom.save') }}"
                >
            </div>
        </div>

        @if ($foundData === [])
            <p class="alert alert-danger">
                {{ __('custom.query_fail') }}
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            </p>
        @elseif (!empty($foundData))
            <div class="m-t-md m-b-md js-show-on-load js-data-table">
                <table class="data-table" data-page-length="10">
                    <thead>
                        @foreach ($foundData as $index => $row)
                            @if ($index == 0)
                                @foreach ($row as $key => $value)
                                    <th><p>{{ $value }}</p></th>
                                @endforeach
                                </thead>
                                <tbody>
                            @else
                                <tr>
                                    @foreach ($row as $key => $value)
                                        <td>{{ $value }}</td>
                                    @endforeach
                                </tr>
                            @endif
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="align-right">
                <input
                    type="button"
                    class="btn btn-primary pull-right js-hide-button"
                    data-target=".js-data-table"
                    value="{{ uctrans('custom.close') }}"
                >
            </div>
        @endif
    </div>
</form>
@endsection
